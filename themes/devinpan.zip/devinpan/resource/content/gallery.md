/*
Title: GALLERY
Date: 2014/01/01
Nav: GALLERY
Priority: 1
Taxonomy: slider
Template: slider
Alias: slider
*/
