/*
Title: CONTACT
Date: 2014/01/01
Nav: CONTACT
Priority: 0
Taxonomy: contact
Template: contact
Alias: contact
Description: contact
Redirect_url: /gallery
*/
<h1>CONTACT</h1>
<p>My Contact Information<p>
<p>Name:Jack</p>
<p>Address: Jingjian St.26,Shanghai,China</p>
<p>Mobile: (+89)18753678435</p>
<p>Email: David_Pan@gmail.com</p>
<div class="row clearfix qrcode-container">
				<h1>Rather Prefer Scaning?</h1>
				<div class="col-md-6 column qrcode">
					<div class="arrow"></div>
					<img alt="140x140" src="/uploads/QR1.jpg" class="img-thumbnail">
				</div>
				<div class="col-md-6 column qrcode">
					<img alt="140x140" src="/uploads/QR2.jpg" class="img-thumbnail">
				</div>